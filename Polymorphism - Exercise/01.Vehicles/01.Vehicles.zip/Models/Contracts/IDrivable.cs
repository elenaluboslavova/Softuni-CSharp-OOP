﻿namespace _01.Vehicles.Models.Contracts
{
    public interface IDrivable
    {
        string Drive(double amount);
    }
}
